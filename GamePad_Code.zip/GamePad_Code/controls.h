#include <Bounce2.h>

int buttonBounce = 10;
Bounce*buttons = new Bounce[4];

int buttonPins[] = {0, 1, 2, 3};

int buttonBuffer[] = {0, 0, 0, 0};

int joystickPins[] = {14, 15};
int joystickBuffer[] = {0, 0};

int val; //value used for the joystick y buffer
int val2; //value used for the joystick x buffer

void initControls() {
  for (int i = 0; i < 4; i++) {
    buttons[i].attach(buttonPins[i], INPUT_PULLUP);
    buttons[i].interval(buttonBounce);
  }
}

void getControls() {
  for (int i = 0; i < 4; i++) {
    buttons[i].update();
    if (buttons[i].rose()) {
      buttonBuffer[i] = 0;
    }
    else {
      buttonBuffer[i] = 1;
    }
  }

int rawVal = analogRead(14);
int rawVal2 = analogRead(15);

//sets the raw values to the preferred values to control the joystick
if (rawVal < 575 && rawVal > 350){
  val = 0;
} else if (rawVal > 575){
  val= 1;
} else if (rawVal < 350){
  val =-1;
}

if (rawVal2 < 575 && rawVal2 > 350){
  val2 = 0;
} else if (rawVal2 > 575){
  val2= 1;
} else if (rawVal2 < 350){
  val2 =-1;
}

  
}

//void joystickRead() {
//  val = analogRead(14);
//  val2 = analogRead(15);
//
//  Serial.println("JoyStick X");
//  Serial.println(val);
//  Serial.println("Joystick Y");
//  Serial.println(val2);
//}
//void buttonRead() {
//  for (int i = 0; i < 4; i++) {
//    Serial.println(buttonBuffer[i]);
//  }
//}
