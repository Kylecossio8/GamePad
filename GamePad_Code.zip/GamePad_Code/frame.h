#include <Metro.h>

Metro timer = Metro(1000);

int frames;

void checkFrame() {
  frames = frames + 1;
  if (timer.check()) {
    Serial.println(frames);
    frames = 0;
  }

}





/*




   void checkFrame(){
  if (timer.check()){
  Serial.println("looped");
  }
  }



*/
