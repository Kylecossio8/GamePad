#include "Haste_MASK.h"
#include "Haste_PIX.h"

//variables needed for the hero function
float heroX;
float heroY;
float heroH;
float heroW;
float heroSpeed;
boolean drawn;
float heroDirc;
int heroFrame; // how many frames per animation 

Metro heroTimer = Metro(200);

int curTileX;
int curTileY;
int curTile;


void setHero(){
  drawn = false;
  heroX = screenW /2;
  heroY = 30;
  heroH = 32;
  heroW = 32;
  heroSpeed = .75;
  heroFrame = 0;
  
}

void drawHero() {
  float nextX; 
  float nextY;

  nextY = (val * heroSpeed) + heroY;
  nextX = (val2 * heroSpeed) + heroX;
  


  //moves hero to the right
  if (val2 > 0) {
    heroDirc = 0;
  }
  
  //moves hero to the left
  if (val < 0) {
  heroDirc = 1;
  }
 
 if (val2 == 0 && heroDirc == 0) {
  heroFrame = 0;
 }
 
  if (val2 == 0 && heroDirc == 1) {
  heroFrame = 4;
 }

 if (val2 == 1 && heroDirc == 0) {
   if (heroTimer.check()) {
    heroFrame = (heroFrame + 1) % 3;
    heroFrame = heroFrame + 1;
    }
 }

  if (val2 == -1 && heroDirc == 1) {
   if (heroTimer.check()) {
    heroFrame = (heroFrame + 1) % 4;
    if (heroFrame < 5) {
      heroFrame = 5;
    }
   }
 }

  boolean canMove = checkMove(currentMode, nextX, nextY, heroW, heroH);
 
  if (canMove == true) {
    heroX=nextX; 
    heroY=nextY;
  }
  tft.setClipRect(heroX - 2, heroY - 2 , 35, 35);
  tft.drawRGBBitmap(heroX, heroY, Haste_PIX[heroFrame], Haste_MASK[heroFrame], 32, 32);

   curTileX = heroX / tileSize;  
   curTileY = heroY / tileSize; 
   curTile = curTileX + (curTileY * tileW);


}


//float nextX = heroX + (float(joystickBuffer[0])*heroSpeed);
//float nextY = heroY + (float(joystickBuffer[0])*heroSpeed);
