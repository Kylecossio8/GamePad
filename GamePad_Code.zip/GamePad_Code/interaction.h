//Generate an Array of Neighbors for Checking
int neighbors[192][8];

void initNeighbors() {
  for (int i = 0; i < tileW * tileH; i++) {
    // General Rule
    int N = i - tileW; int NE = (i - tileW) + 1;  int E = i + 1;  int SE = (i + tileW) + 1;
    int S = i + tileW; int SW = (i + tileW) - 1;  int W = i - 1;  int NW = (i - tileW) - 1;

    // Exceptions
    if (i < tileW) {
      NW = -1;
      N = -1;
      NE = -1;
    }
    if (i > (tileW * tileH) - (tileW + 1)) {
      SW = -1;
      S = -1;
      SE = -1;
    }
    if (i % tileW == 0) {
      NW = -1;
      W = -1;
      SW = -1;
    }
    if ((i + 1) % tileW == 0) {
      NE = -1;
      E = -1;
      SE = -1;
    }

    neighbors[i][0] = N;  neighbors[i][1] = NE;  neighbors[i][2] = E;  neighbors[i][3] = SE;
    neighbors[i][4] = S;  neighbors[i][5] = SW;  neighbors[i][6] = W;  neighbors[i][7] = NW;
  }
}

boolean checkMove(int currentLevel, int curX, int curY, int curW, int curH) {
  boolean canMove = true;

  curX = curX + 2;
  curY = curY + 2;

  int curTileX = curX  / tileSize;
  int curTileY = curY / tileSize;
  int curTile = curTileX + (curTileY * tileW);


  for (int i = 0; i < 8; i++) {
    int whichTile = neighbors[curTile][i];             
    int neighborX = (whichTile % tileW) * tileSize;      
    int neighborY = (whichTile / tileW) * tileSize;      

    boolean isOut = false;
    boolean xMin = false;
    boolean yMin = false;
    boolean xMax = false;
    boolean yMax = false;

    if (interaction[currentLevel][whichTile] == 0xFF) {
      isOut = true;
    } if (curX < neighborX + tileSize) {
      xMin = true;
    } if (curX + curW > neighborX) {
      xMax = true;
    } if (curY < neighborY + tileSize) {
      yMin = true;
    } if (curY < neighborY + tileSize) {
      yMax = true;
    }

    if (isOut == true && xMin == true && xMax == true && yMin == true && yMax == true) {
      canMove = false;

    }

  }

  return canMove;
}




}
