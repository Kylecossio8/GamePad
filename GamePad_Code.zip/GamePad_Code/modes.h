

int curMode = -1;
int x;
int y;
int w;
int h;
boolean initIntro = false;
boolean initOutside = false;
boolean initMainroom = false;
boolean initHallway1 = false;
boolean initKitchen = false;
boolean intitBedroom = false;
boolean initHallway2 = false;
boolean initBathroom = false;
boolean initBasement = false;
boolean initEnd = false;
boolean initOver = false;

 This is the introscreen and will include the intrographic and the controls for the game
void introScreen(){
  if(initIntro == false){
    tft.setClipRect(0,0,screenW,screenH);
    tft.drawRGBBitmap(x,y,graphic[0],w,h);
    tft.updateScreen();
    //heroX = ;
    //heroY = ;
  }
  initIntro = true;
}
 This is the first level and where you start the game.
void outside(){
  if(initOutside == false){
    tft.setClipRect(0,0,screenW,screenH);
    drawLevel(0);
    drawHero();
    //tft.drawRGBBitmap(x,y,graphic[0],w,h);
    tft.updateScreen();
  }
  initOutside = true;
}
 This is the next area and will serve as the hub and the main area that the player will continuously comeback to 
void mainroom(){
  if(initmainRoom == false){
    tft.setClipRect(0,0,screenW,screenH);
    drawLevel(1);
    drawHero();
    //tft.drawRGBBitmap(x,y,graphic[0],w,h);
    tft.updateScreen();
  }
  initmainRoom = true;
}
 Leads to the bedroom and bathroom
void hallway1(){
  if(initHallway1 == false){
    tft.setClipRect(0,0,screenW,screenH);
    drawLevel(2);
    drawHero();
    //tft.drawRGBBitmap(x,y,graphic[0],w,h);
    tft.updateScreen();
  }
  initHallway1 = true;
}
 This is one of the key areas and will contain a knife that the player can grab to progress through the game and open the door to the bedroom
void kitchen(){
  if(initKitchen == false){
    tft.setClipRect(0,0,screenW,screenH);
    //tft.drawRGBBitmap(x,y,graphic[0],w,h);
    tft.updateScreen();
  }
  initKitchen = true;
}
 Will contain the key to the front door
void bedroom(){
  if(initBedroom == false){
    tft.setClipRect(0,0,screenW,screenH);
    //tft.drawRGBBitmap(x,y,graphic[0],w,h);
    tft.updateScreen();
  }
  initBedroom = true;
}
 Wll lead to the basement
void hallway2(){
  if(initHallway2 == false){
    tft.setClipRect(0,0,screenW,screenH);
    //tft.drawRGBBitmap(x,y,graphic[0],w,h);
    tft.updateScreen();
  }
  initHallway2 = true;
}
 You can find the key to the basement
void bathroom(){
  if(initBathroom == false){
    tft.setClipRect(0,0,screenW,screenH);
    //tft.drawRGBBitmap(x,y,graphic[0],w,h);
    tft.updateScreen();
  }
  initBathroom = true;
}
you can find gas in the basement along with an enemy guarding the final room
void basement(){
  if(initBasement == false){
    tft.setClipRect(0,0,screenW,screenH);
    //tft.drawRGBBitmap(x,y,graphic[0],w,h);
    tft.updateScreen();
  }
  initBasement = true;
}
 This is the endscreen when you win and complete the game
void endScreen(){
  if(initEnd == false){
    tft.setClipRect(0,0,screenW,screenH);
    //tft.drawRGBBitmap(x,y,graphic[0],w,h);
    tft.updateScreen();
  }
  initEnd = true;
}
 This is the gameover screen when you lose the game
void gameOver(){
  if(initOver == false){
    tft.setClipRect(0,0,screenW,screenH);
    //tft.drawRGBBitmap(x,y,graphic[0],w,h);
    tft.updateScreen();
  }
  initOver = true;
}
void runMode(){
  switch(curMode){
    case -1: introScreen();
    break;
    case 0: outside();
    break;
    case 1: mainroom();
    break;
    case 2: hallway1();
    break;
    case 3: kitchen();
    break;
    case 4: bedroom();
    break;
    case 5: hallway2();
    break;
    case 6: bathroom();
    break;
    case 7: basement();
    break;
    case 8: endScreen();
    break;
    case 9: gameOver();
    break;
  }
}


//  if(getControls(button.rose == true)){
//    curMode = 0;
//  }
